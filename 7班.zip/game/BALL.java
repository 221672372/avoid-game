import greenfoot.*;

/**
 * Write a description of class BALL here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BALL extends Actor
{
    /**
     * Act - do whatever the BALL wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    
    private int rtime = 500;
    
    public void act() 
    {
        rtime--;
        
    }    
}
